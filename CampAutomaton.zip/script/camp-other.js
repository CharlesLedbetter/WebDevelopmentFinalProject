/*********************************************************************
** Assignment: Final Project
** Author: Charles Ledbetter
** Date: 11/19/2017
** Description: script for camp.html and other.html
*********************************************************************/
//scrollify initialization
$(function() {
  $.scrollify({
    section:".panel",
    easing:"swing",
    scrollbars:true,
    overflowScroll:true
  });
});
